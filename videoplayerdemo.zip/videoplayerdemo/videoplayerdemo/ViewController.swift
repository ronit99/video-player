//
//  ViewController.swift
//  videoplayerdemo
//
//  Created by Romit Patel on 19/04/19.
//  Copyright © 2019 Romit Patel. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class ViewController: UIViewController,AVPlayerViewControllerDelegate {

    @IBOutlet weak var playbtn: UIButton!
    @IBOutlet weak var playerslider: UISlider!
    @IBOutlet weak var overalltxt: UILabel!
    @IBOutlet weak var currentdurtxt: UILabel!
    var player = AVPlayer()
    var timerduration = Timer()
    var playerControllers = AVPlayerViewController()
    var isVideoPlaying = false
    var timer = Timer()
    var checkpalyerstatus : String!
    @IBOutlet weak var videoviw: UIView!
    var playerLayer: AVPlayerLayer?
    var adding_times : Int = 0
    var myarraylike = [String:Any]()
    var webduratin : NSNumber =  31
    @IBOutlet weak var btnfull: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
//        playerController.showsPlaybackControls = false
        
        playerslider.addTarget(self, action: #selector(self.handlePlayheadSliderTouchBegin), for: .touchDown)
        playerslider.addTarget(self, action:    #selector(self.handlePlayheadSliderTouchEnd), for: .touchUpInside)
        playerslider.addTarget(self, action: #selector(self.handlePlayheadSliderTouchEnd), for: .touchUpOutside)
        playerslider.addTarget(self, action: #selector(self.handlePlayheadSliderValueChanged), for: .valueChanged)

        playerControllers.addObserver(self, forKeyPath: #keyPath(AVPlayerViewController.videoBounds), options: [.old, .new], context: nil)

        self.playVideo()


    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey: Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == #keyPath(AVPlayerViewController.videoBounds) {
            // detect only changes
            if let oldValue = change?[.oldKey] as? CGRect, oldValue == CGRect.zero, let newValue = change?[.newKey] as? CGRect {
                // no need to track the initial bounds change, and only changes
                if !oldValue.equalTo(CGRect.zero), !oldValue.equalTo(newValue) {
                    if newValue.size.height < UIScreen.main.bounds.height {
                        print("normal screen")
                    } else {
                        print("fullscreen")
                    }
                }
            }

        }
    }
    // play  audio or video in silent mode
    func setupAudio() {
    let audioSession = AVAudioSession.sharedInstance()
    _ = try? audioSession.setCategory(AVAudioSessionCategoryPlayback, with: .duckOthers)
    _ = try? audioSession.setActive(true)
}
    func playVideo() {
//        let videoURL = NSURL(string: "https://my-cpe.com/uploads/webinar_video/1558004769.mp4")
        var urlfirst = "https://my-cpe.com/uploads/webinar_video/1558004769.mp4"
        var videoURL = urlfirst.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        var afterurl  = NSURL(string:videoURL!)
        player = AVPlayer(url: afterurl! as URL)
//        let playerController = AVPlayerViewController()
        playerControllers.player = player
        playerControllers.showsPlaybackControls = false
        self.addChildViewController(playerControllers)
        // Add your view Frame
        let rect = CGRect(x: 0, y: 0, width:  self.videoviw.frame.width, height:  self.videoviw.frame.height)
        playerControllers.view.frame = rect
        // Add sub view in your view
        self.videoviw.addSubview(playerControllers.view)
        self.setupAudio()
        if player.timeControlStatus == .playing
        {
            DispatchQueue.main.async
                {
                    print("pause")
                    self.player.play()
                    let duration : CMTime = self.player.currentItem!.asset.duration
                    let seconds : Float64 = CMTimeGetSeconds(duration)
                    self.overalltxt.text = self.stringFromTimeInterval(interval: seconds)
                    let durationcur : CMTime = self.player.currentTime()
                    let secondscur : Float64 = CMTimeGetSeconds(duration)
                    self.currentdurtxt.text = self.stringFromTimeInterval(interval: secondscur)
                    self.updateVideoPlayerSlider()
                    NotificationCenter.default.addObserver(self, selector: #selector(self.playerDidFinishPlaying), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: self.playerControllers.player?.currentItem)
                    self.player.actionAtItemEnd = AVPlayerActionAtItemEnd.none
                    self.checkpalyerstatus == "starts"
                    self.runTimer()
            }
        } else if player.timeControlStatus == .paused {
            print("play")
        }
    }

    func frombackground()
    {
        let state = UIApplication.shared.applicationState
                if state == .background
                {
                    print("App in Background")
                }
                else if state == .active
                {
                    print("App in Foreground or Active")
                }
    }
    func forgroundstate()
    {
        
            print("app killed")
    }
    @IBAction func handlePlayPauseButtonPressed(_ sender: UIButton) {
        //  sender.isSelected ?  currentPlayer.pause() :   currentPlayer.play()
       if (player.rate != 0 && player.error == nil && checkpalyerstatus == "starts")
       {
            player.pause()
           playbtn.setTitle("Play", for: .normal)
           checkpalyerstatus = "ends"
        }
        else {
            player.play()
//        if player.timeControlStatus != AVPlayerTimeControlStatus.playing
           playbtn.setTitle("Pause", for: .normal)
            let duration : CMTime = player.currentItem!.asset.duration
            let seconds : Float64 = CMTimeGetSeconds(duration)
            overalltxt.text = self.stringFromTimeInterval(interval: seconds)
            let durationcur : CMTime = player.currentTime()
            let secondscur : Float64 = CMTimeGetSeconds(duration)
            currentdurtxt.text = self.stringFromTimeInterval(interval: secondscur)
            self.updateVideoPlayerSlider()
        NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: playerControllers.player?.currentItem)
        player.actionAtItemEnd = AVPlayerActionAtItemEnd.none
         checkpalyerstatus = "starts"
            self.runTimer()
        }
    }
    func reviseplayertime()
    {
        //        btnfull.isHidden = true
        
        DispatchQueue.main.async
            {
                print("pause")
                self.player.play()
                let duration : CMTime = self.player.currentItem!.asset.duration
                let seconds : Float64 = CMTimeGetSeconds(duration)
                self.overalltxt.text = self.stringFromTimeInterval(interval: seconds)
                let durationcur : CMTime = self.player.currentTime()
                let secondscur : Float64 = CMTimeGetSeconds(duration)
                self.currentdurtxt.text = self.stringFromTimeInterval(interval: secondscur)
                self.updateVideoPlayerSlider()
                NotificationCenter.default.addObserver(self, selector: #selector(self.playerDidFinishPlaying), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: self.playerControllers.player?.currentItem)
                self.player.actionAtItemEnd = AVPlayerActionAtItemEnd.none
                self.runTimer()
        }
    }

    @IBAction func btnfull(_ sender: Any) {
        playerControllers.showsPlaybackControls = true
        btnfull.isHidden = true
       
            DispatchQueue.main.async
                {
                    print("pause")
            self.player.play()
            let duration : CMTime = self.player.currentItem!.asset.duration
            let seconds : Float64 = CMTimeGetSeconds(duration)
            self.overalltxt.text = self.stringFromTimeInterval(interval: seconds)
            let durationcur : CMTime = self.player.currentTime()
            let secondscur : Float64 = CMTimeGetSeconds(duration)
            self.currentdurtxt.text = self.stringFromTimeInterval(interval: secondscur)
            self.updateVideoPlayerSlider()
            NotificationCenter.default.addObserver(self, selector: #selector(self.playerDidFinishPlaying), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: self.playerControllers.player?.currentItem)
            self.player.actionAtItemEnd = AVPlayerActionAtItemEnd.none
             self.runTimer()
            self.caluserduration()
            self.runtimerduration()
            self.reviseplayertime()
            }
        
        
    }
    @objc func playerDidFinishPlaying(note: NSNotification) {
        print("ends")
        self.timer.invalidate()
        playbtn.setTitle("Play", for: .normal)
        checkpalyerstatus = "ends"
        playerslider.value = 0
        currentdurtxt.text = "00:00"
        overalltxt.text = "00:00"
        player.seek(to: kCMTimeZero)
}
    @objc func updateVideoPlayerSlider() {
        //playing time

        if (player.rate != 0 && player.error == nil) {
            // 1 . Guard got compile error because `videoPlayer.currentTime()` not returning an optional. So no just remove that.
            let currentTimeInSeconds = CMTimeGetSeconds(player.currentTime())
            // 2 Alternatively, you could able to get current time from `currentItem` - videoPlayer.currentItem.duration
            
            let mins = currentTimeInSeconds / 60
            let secs = currentTimeInSeconds.truncatingRemainder(dividingBy: 60)
            let timeformatter = NumberFormatter()
            timeformatter.minimumIntegerDigits = 2
            timeformatter.minimumFractionDigits = 0
            timeformatter.roundingMode = .down
            guard let minsStr = timeformatter.string(from: NSNumber(value: mins)), let secsStr = timeformatter.string(from: NSNumber(value: secs)) else {
                return
            }
            currentdurtxt.text = "\(minsStr).\(secsStr)"
            playerslider.value = Float(currentTimeInSeconds) // I don't think this is correct to show current progress, however, this update will fix the compile error
            adding_times = Int(currentTimeInSeconds)
            // 3 My suggestion is probably to show current progress properly
            if let currentItem = player.currentItem {
                let duration = currentItem.duration
                if (CMTIME_IS_INVALID(duration)) {
                    // Do sth
                    return;
                }
                let currentTime = currentItem.currentTime()
                playerslider.value = Float(CMTimeGetSeconds(currentTime) / CMTimeGetSeconds(duration))
              //  print(playerslider.value)
                print(currentdurtxt.text)
            }
        }
        else
        {
//                playerControllers.showsPlaybackControls = false
            timer.invalidate()
            if #available(iOS 11.0, *) {
                self.playerControllers.exitsFullScreenWhenPlaybackEnds = true
            }
            
          
        }
       
    }
    func playerItemDidReachEnd(note:NSNotification){
        print("finished")
        dismiss(animated: true, completion: nil)
    }
    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(ViewController.updateVideoPlayerSlider)), userInfo: nil, repeats: true)
    }
    func getTimeString(from time: CMTime) -> String {
        let totalSeconds = CMTimeGetSeconds(time)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        if hours > 0 {
            return String(format: "%i:%02i:%02i", arguments: [hours,minutes,seconds])
        }else {
            return String(format: "%i:%02i:%02i", arguments: [hours,minutes,seconds])
        }
    }
    func stringFromTimeInterval(interval: TimeInterval) -> String {

        let interval = Int(interval)
        let seconds = interval % 60
        let minutes = (interval / 60) % 60
        let hours = (interval / 3600)
        return String(format: "%02d:%02d", hours, minutes, seconds)
    }
    @IBAction func handlePlayheadSliderTouchBegin(_ sender: UISlider) {
        player.pause()
        
    }
    @IBAction func handlePlayheadSliderValueChanged(_ sender: UISlider) {

        let duration : CMTime = player.currentItem!.asset.duration
        let seconds : Float64 = CMTimeGetSeconds(duration) * Double(sender.value)
        //   var newCurrentTime: TimeInterval = sender.value * CMTimeGetSeconds(currentPlayer.currentItem.duration)
        currentdurtxt.text = self.stringFromTimeInterval(interval: seconds)
    }
    @IBAction func handlePlayheadSliderTouchEnd(_ sender: UISlider) {

        let duration : CMTime = player.currentItem!.asset.duration
        var newCurrentTime: TimeInterval = Double(sender.value) * CMTimeGetSeconds(duration)
        var seekToTime: CMTime = CMTimeMakeWithSeconds(newCurrentTime, 600)
//        player.seek(toTime: seekToTime)
      //  playerslider.value = Float(newCurrentTime)
        player.seek(to: seekToTime)
        player.play()
        print(newCurrentTime)
        timer.invalidate()
        self.runTimer()
    }
    func caluserduration()
    {
        
            //ACProgressHUD.shared.showHUD()
            // ACProgressHUD.shared.progressText = ""
        let usertokendel = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL215LWNwZS5jb20vYXBpL2xvZ2luIiwiaWF0IjoxNTY1Njk2OTk4LCJleHAiOjE1NjU3ODMzOTgsIm5iZiI6MTU2NTY5Njk5OCwianRpIjoiNW9WalZSNEJCcEVXS2VUSiIsInN1YiI6MiwicHJ2IjoiMjNiZDVjODk0OWY2MDBhZGIzOWU3MDFjNDAwODcyZGI3YTU5NzZmNyJ9.S0rsNligCEnQi03aO7EQBTDWIpfem9Pn-xLrTkC5wFE"
            let urlcomb  = "https://my-cpe.com/api/webinar/video-duration"
            let stringurl = URL(string: urlcomb)
            var request = URLRequest(url: stringurl! as URL)
            let parameterDictionary = ["webinar_id" :"157","play_time_duration":adding_times,"presentation_length":self.webduratin] as [String : Any]
            request.httpMethod = "POST"
            request.setValue("Bearer \(usertokendel)", forHTTPHeaderField: "Authorization")
            request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
            guard let httpBody = try? JSONSerialization.data(withJSONObject: parameterDictionary, options: []) else
            {
                return
            }
            request.httpBody = httpBody
            
            let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, let _ = response, error == nil else {
                    return
                }
                let response1 = response as! HTTPURLResponse
                print(response1.statusCode) // 200 instead of 304
                if response1.statusCode == 401
                {
                    print("Refresh token...")
                    return
                }
                else
                {
                    //                        print("else error")
                    print("error: \(String(describing: error))")
                }
                let responseString = String(data: data, encoding: .utf8)
                do
                {
                    let parsedData = try JSONSerialization.jsonObject(with: data) as! [String:Any]
                    self.myarraylike=parsedData
                    let datacheckstr:Bool=(self.myarraylike["success"] as! Bool)
                    if datacheckstr == true
                    {
                        var dictonary:NSDictionary?
                        do {
                            dictonary = try JSONSerialization.jsonObject(with: data, options: []) as? [String:AnyObject] as! NSDictionary
                            if let myDictionary = dictonary
                            {
                                var mynewdictionary = myDictionary.value(forKey: "payload") as! NSDictionary
                                print(mynewdictionary)
                                let addstrchek = myDictionary.value(forKey: "message") as! String!
                                DispatchQueue.main.async
                                    {
                                        print("sent time")
                                }
                                
                            }
                        }
                        catch let error as NSError
                        {
                            print(error)
                        }
                    }
                    else
                    {
                        let alert = UIAlertController(title: "Alert", message: "no data found", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                catch
                {
                    print(error)
                }
                
            }
            task.resume()
    }
    
    func runtimerduration()
    {
        timerduration = Timer.scheduledTimer(timeInterval: 10, target: self,   selector: (#selector(ViewController.senddurationsequence)), userInfo: nil, repeats: true)
    }
    @objc func senddurationsequence() {
        self.caluserduration()
    }
}
extension CGAffineTransform {
    
    static let ninetyDegreeRotation = CGAffineTransform(rotationAngle: CGFloat(M_PI / 2))
}

extension AVPlayerLayer {
    
    var fullScreenAnimationDuration: TimeInterval {
        return 0.15
    }
    
    func minimizeToFrame(_ frame: CGRect) {
        UIView.animate(withDuration: fullScreenAnimationDuration) {
            self.setAffineTransform(.identity)
            self.frame = frame
        }
    }
    
    func goFullscreen() {
        UIView.animate(withDuration: fullScreenAnimationDuration) {
            self.setAffineTransform(.ninetyDegreeRotation)
            self.frame = UIScreen.main.bounds
        }
    }
}
extension AVPlayer{
    
    var isPlaying: Bool{
        return rate != 0 && error == nil
    }
}
